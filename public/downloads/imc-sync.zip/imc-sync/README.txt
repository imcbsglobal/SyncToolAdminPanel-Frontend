Database Synchronization Tool
=============================

Setup Instructions:
1. Ensure you have SQL Anywhere ODBC driver installed and configured
2. Make sure you have a DSN set up for your SQL Anywhere database
3. Place the sync-config-XXXXXXXX.json file in this folder
4. Run the sync-client-XXXXXXXX.bat file to start synchronization

If the tool can't find your database, it will list available DSNs and 
prompt you to select one. Your configuration will be updated automatically.

For support, contact: support@yourdomain.com